# HOOD//LAUNCH — Bounty submission

**Live-build objective:** a launcher launcher for Robinhood Chain where each launcher can only create tokens that are paired with `$HOODIE` (`0xC72c01AAB5f5678dc1d6f5C6d2B417d91D402Ba3`).

## What is built

`HoodieTokenLauncherLauncher` is a permissionless factory. Anyone calls `createLauncher()`, which deploys a new `HoodieTokenLauncher`.

Every launcher is irreversibly bound to the same `$HOODIE` address. The address is a Solidity `constant`, so there is no owner action, initializer, proxy upgrade, constructor option, frontend switch, or launch-time argument that can replace it.

To launch a token, the caller provides a fixed supply, the token allocation to put into the pool, and an amount of `$HOODIE`. The launcher then completes the following in **one atomic transaction**:

1. Deploys an immutable-supply ERC-20.
2. Deploys a `HoodiePool` with immutable `token` and `$HOODIE` addresses.
3. Transfers the token allocation and approved `$HOODIE` to that pool.
4. Initializes LP shares only after both reserves are present.
5. Sends the remaining supply and LP shares to the launch recipient.

If any stage fails, no token is launched. An unfunded launch is rejected.

## Judge checklist

1. Open `contracts/HoodieTokenLauncherLauncher.sol` and confirm `HOODIE` is the bounty address and a `constant`.
2. Confirm `HoodieTokenLauncher.launchToken` has no alternate quote-token or AMM parameter.
3. Confirm it transfers approved `$HOODIE` to `new HoodiePool(token, hoodie)` before `initialize`.
4. Open `contracts/HoodiePool.sol` and confirm `hoodie` and `token` are immutable, and swaps only use those assets.
5. Run `npm.cmd install` then `npm.cmd test` — the suite proves the address binding, funded-pool launch, `$HOODIE` swap path, and unfunded-launch rejection.

## Deployment

Robinhood Chain mainnet uses chain ID `4663` and ETH for gas. Copy `.env.example` to `.env`, set only `DEPLOYER_PRIVATE_KEY`, then run the preflight. It rejects a wrong chain, an address with no `$HOODIE` code, or a deployer with no gas:

```powershell
npm.cmd run preflight:mainnet
```

Then deploy:

```powershell
npm.cmd run deploy:mainnet
```

Verify the deployed factory source immediately afterward:

```powershell
npm.cmd run verify:mainnet -- 0xYourFactoryAddress
```

The deploy script logs the contract address and the hard-coded `$HOODIE` address. Verify the source on the Robinhood Chain Blockscout explorer after deployment. Testnet uses chain ID `46630`:

```powershell
npm.cmd run deploy:testnet
```

## Demo flow

1. Serve the repository root and open `app/index.html`.
2. Connect an EVM wallet; the app requests Robinhood Chain.
3. Enter the deployed factory address and create a launcher.
4. Set a total supply, pool-token allocation, and `$HOODIE` liquidity amount.
5. Approve `$HOODIE`, then launch. The app displays the token and pool addresses from the confirmed event.

The browser app is static and non-custodial: it has no backend, database, analytics, private-key handling, or custody path.

See `SECURITY.md` for explicit guarantees, limitations, and the pre-mainnet checklist.

## Suggested reply to enter

> Built HOOD//LAUNCH: a permissionless launcher-launcher for Robinhood Chain. Every launcher is hard-bound to `$HOODIE`, and every token launch atomically deploys + funds an immutable `$HOODIE` pool. No owner key, upgrade path, alternative quote token, or external AMM dependency. Code + demo: [insert hosted repository/app link]
