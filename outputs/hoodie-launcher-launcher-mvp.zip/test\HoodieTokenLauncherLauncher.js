const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("HoodieTokenLauncherLauncher", function () {
  const HOODIE = "0xC72c01AAB5f5678dc1d6f5C6d2B417d91D402Ba3";

  async function deploy() {
    const [creator, recipient] = await ethers.getSigners();
    const Mock = await ethers.getContractFactory("MockERC20");
    const implementation = await Mock.deploy();
    const code = await ethers.provider.getCode(await implementation.getAddress());
    await ethers.provider.send("hardhat_setCode", [HOODIE, code]);
    const hoodie = await ethers.getContractAt("MockERC20", HOODIE);
    await hoodie.mint(creator.address, ethers.parseEther("1000"));
    const Factory = await ethers.getContractFactory("HoodieTokenLauncherLauncher");
    const factory = await Factory.deploy();
    return { creator, recipient, hoodie, factory };
  }

  it("binds every created launcher to the bounty HOODIE address", async function () {
    const { creator, factory } = await deploy();
    await expect(factory.createLauncher()).to.emit(factory, "LauncherCreated");
    const launcherAddress = await factory.launchers(0);
    const launcher = await ethers.getContractAt("HoodieTokenLauncher", launcherAddress);
    expect(await launcher.hoodie()).to.equal(HOODIE);
    expect(await launcher.creator()).to.equal(creator.address);
  });

  it("creates and funds a pool with HOODIE, never a caller-selected asset", async function () {
    const { creator, recipient, hoodie, factory } = await deploy();
    await factory.createLauncher();
    const launcher = await ethers.getContractAt("HoodieTokenLauncher", await factory.launchers(0));
    const supply = ethers.parseEther("1000000");
    const hoodieAmount = ethers.parseEther("10");
    await hoodie.connect(creator).approve(await launcher.getAddress(), hoodieAmount);
    const receipt = await (await launcher.launchToken("A Launch", "ALCH", supply, ethers.parseEther("500000"), hoodieAmount, recipient.address)).wait();
    const event = receipt.logs.map((log) => { try { return launcher.interface.parseLog(log); } catch { return null; } }).find(Boolean);
    const token = event.args.token;
    const pool = await ethers.getContractAt("HoodiePool", event.args.pair);
    expect(await pool.hoodie()).to.equal(HOODIE);
    expect(await pool.token()).to.equal(token);
    expect(await pool.reserveHoodie()).to.equal(hoodieAmount);
    const launched = await ethers.getContractAt("LaunchToken", token);
    expect(await launched.balanceOf(recipient.address)).to.equal(ethers.parseEther("500000"));
    expect(await launcher.launchCount()).to.equal(1n);
    const record = await launcher.launchAt(0);
    expect(record.token).to.equal(token);
    expect(record.pool).to.equal(event.args.pair);
    expect(record.recipient).to.equal(recipient.address);
    expect(record.supply).to.equal(supply);
  });

  it("routes swaps through the immutable HOODIE pool", async function () {
    const { creator, recipient, hoodie, factory } = await deploy();
    await factory.createLauncher();
    const launcher = await ethers.getContractAt("HoodieTokenLauncher", await factory.launchers(0));
    const hoodieAmount = ethers.parseEther("10");
    await hoodie.approve(await launcher.getAddress(), hoodieAmount);
    const receipt = await (await launcher.launchToken("A Launch", "ALCH", ethers.parseEther("1000000"), ethers.parseEther("500000"), hoodieAmount, recipient.address)).wait();
    const event = receipt.logs.map((log) => { try { return launcher.interface.parseLog(log); } catch { return null; } }).find(Boolean);
    const pool = await ethers.getContractAt("HoodiePool", event.args.pair);
    const inAmount = ethers.parseEther("1");
    await hoodie.approve(await pool.getAddress(), inAmount);
    const before = await (await ethers.getContractAt("LaunchToken", event.args.token)).balanceOf(creator.address);
    await pool.swapHoodieForToken(inAmount, 1, creator.address);
    expect(await (await ethers.getContractAt("LaunchToken", event.args.token)).balanceOf(creator.address)).to.be.gt(before);
    expect(await pool.reserveHoodie()).to.equal(hoodieAmount + inAmount);
  });

  it("refuses an unfunded launch, so every emitted launch has HOODIE liquidity", async function () {
    const { recipient, factory } = await deploy();
    await factory.createLauncher();
    const launcher = await ethers.getContractAt("HoodieTokenLauncher", await factory.launchers(0));
    await expect(
      launcher.launchToken("No Pool", "NOPE", ethers.parseEther("1000"), ethers.parseEther("500"), 0, recipient.address)
    ).to.be.revertedWith("BAD_INITIAL_LIQUIDITY");
  });

  it("enforces a caller's minimum output on HOODIE swaps", async function () {
    const { creator, recipient, hoodie, factory } = await deploy();
    await factory.createLauncher();
    const launcher = await ethers.getContractAt("HoodieTokenLauncher", await factory.launchers(0));
    const hoodieAmount = ethers.parseEther("10");
    await hoodie.approve(await launcher.getAddress(), hoodieAmount);
    const receipt = await (await launcher.launchToken("A Launch", "ALCH", ethers.parseEther("1000000"), ethers.parseEther("500000"), hoodieAmount, recipient.address)).wait();
    const event = receipt.logs.map((log) => { try { return launcher.interface.parseLog(log); } catch { return null; } }).find(Boolean);
    const pool = await ethers.getContractAt("HoodiePool", event.args.pair);
    const input = ethers.parseEther("1");
    await hoodie.approve(await pool.getAddress(), input);
    await expect(pool.swapHoodieForToken(input, ethers.parseEther("999999"), creator.address)).to.be.revertedWith("SLIPPAGE");
    expect(await pool.reserveHoodie()).to.equal(hoodieAmount);
  });

  it("lets an LP holder redeem proportional token and HOODIE liquidity", async function () {
    const { creator, recipient, hoodie, factory } = await deploy();
    await factory.createLauncher();
    const launcher = await ethers.getContractAt("HoodieTokenLauncher", await factory.launchers(0));
    const hoodieAmount = ethers.parseEther("10");
    await hoodie.connect(creator).approve(await launcher.getAddress(), hoodieAmount);
    const receipt = await (await launcher.launchToken("A Launch", "ALCH", ethers.parseEther("1000000"), ethers.parseEther("500000"), hoodieAmount, recipient.address)).wait();
    const event = receipt.logs.map((log) => { try { return launcher.interface.parseLog(log); } catch { return null; } }).find(Boolean);
    const pool = await ethers.getContractAt("HoodiePool", event.args.pair);
    const token = await ethers.getContractAt("LaunchToken", event.args.token);
    const shares = await pool.balanceOf(recipient.address);
    const burn = shares / 2n;
    const tokenBefore = await token.balanceOf(recipient.address);
    const hoodieBefore = await hoodie.balanceOf(recipient.address);
    await pool.connect(recipient).removeLiquidity(burn, recipient.address);
    expect(await token.balanceOf(recipient.address)).to.be.gt(tokenBefore);
    expect(await hoodie.balanceOf(recipient.address)).to.be.gt(hoodieBefore);
    expect(await pool.balanceOf(recipient.address)).to.equal(shares - burn);
  });
});
